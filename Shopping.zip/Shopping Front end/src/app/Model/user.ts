export interface User {
  fullname: string,
  email: string;
  username: string;
  password: string;
  usertype: string;
}
